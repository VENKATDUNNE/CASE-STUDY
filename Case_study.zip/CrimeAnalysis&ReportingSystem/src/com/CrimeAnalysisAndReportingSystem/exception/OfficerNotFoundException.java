package com.CrimeAnalysisAndReportingSystem.exception;

public class OfficerNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OfficerNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OfficerNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
