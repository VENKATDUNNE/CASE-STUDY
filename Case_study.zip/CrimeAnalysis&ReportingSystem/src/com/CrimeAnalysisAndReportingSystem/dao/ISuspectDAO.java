package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.exception.SuspectNotFoundException;

public interface ISuspectDAO {
	public int addSuspect(Suspects suspect) throws ClassNotFoundException, SQLException;

	public int updateSuspect(Suspects suspect) throws ClassNotFoundException, SQLException, SuspectNotFoundException;

	public int deleteSuspect(int suspectId) throws ClassNotFoundException, SQLException, SuspectNotFoundException;

	public Suspects viewSuspect(int suspectId) throws ClassNotFoundException, SQLException, SuspectNotFoundException;

	public List<Suspects> viewSuspects() throws ClassNotFoundException, SQLException, SuspectNotFoundException;
}
