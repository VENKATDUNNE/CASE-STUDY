package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Evidence;
import com.CrimeAnalysisAndReportingSystem.exception.EvidenceNotFoundException;

public interface IEvidenceDAO {
	public int addEvidence(Evidence evidence) throws ClassNotFoundException, SQLException;
	public int updateEvidence(Evidence evidence) throws ClassNotFoundException, SQLException, EvidenceNotFoundException;
	public int deleteEvidence(int evidenceID) throws ClassNotFoundException, SQLException, EvidenceNotFoundException;
	public Evidence viewEvidence(int evidenceID) throws ClassNotFoundException, SQLException, EvidenceNotFoundException;
	public List<Evidence>viewEvidences() throws ClassNotFoundException, SQLException, EvidenceNotFoundException;

}
