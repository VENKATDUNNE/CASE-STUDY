package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.AgencyNotFoundException;


public class LawEnforcementAgenciesDAOImplTest {

	private ILawEnforcementAgenciesDAO leaDAO;

	@Before
	public void setUp() throws Exception {
		leaDAO = new LawEnforcementAgenciesDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		leaDAO = null;
	}

	@Test
	public final void testAddLawEnforcementAgency() {
		int result = 0;
		Officers officer = new Officers();
		int OfficerID = 10;
		officer.setOfficerId(OfficerID);
		lawEnforcementAgencies lea = new lawEnforcementAgencies("KPY", "CHENNAI", "9098976900");
		try {
			result = leaDAO.addLawEnforcementAgency(lea);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateLawEnforcementAgency() {
		int result = 0;
		Officers officer = new Officers();
		int OfficerID = 10;
		officer.setOfficerId(OfficerID);
		lawEnforcementAgencies lea = new lawEnforcementAgencies(5, "KPY", "CHENNAI", "9098976900");
		try {
			result = leaDAO.updateLawEnforcementAgency(lea);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteLawEnforcementAgency() {
		int result = 0;
		int agencyID = 2;
		try {
			result = leaDAO.deleteLawEnforcementAgency(agencyID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(result == 1);
	}

	@Test
	public final void testViewLawEnforcementAgency() {
		lawEnforcementAgencies lea = null;
		int agencyID = 1;

		try {
			lea = leaDAO.viewLawEnforcementAgency(agencyID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(lea != null);
	}

	@Test
	public final void testViewLawEnforcementAgencies() {
		List<lawEnforcementAgencies> leaList = null;

		try {
			leaList = leaDAO.viewLawEnforcementAgencies();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (AgencyNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(leaList != null);
	}

}
