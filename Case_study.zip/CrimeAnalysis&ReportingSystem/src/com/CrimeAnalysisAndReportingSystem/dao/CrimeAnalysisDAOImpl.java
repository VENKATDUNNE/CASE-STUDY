package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.CaseNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.IncidentNumberNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;
import com.CrimeAnalysisAndReportingSystem.service.CrimeAnalysisServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.ICrimeAnalysisService;
import com.CrimeAnalysisAndReportingSystem.service.ISuspectService;
import com.CrimeAnalysisAndReportingSystem.service.IVictimService;
import com.CrimeAnalysisAndReportingSystem.service.SuspectServiceImpl;
import com.CrimeAnalysisAndReportingSystem.service.VictimServiceImpl;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;

public class CrimeAnalysisDAOImpl implements ICrimeAnalysisDAO {
	private static Connection connCrime;

	@Override
	public boolean createIncident(Incidents incident) throws ClassNotFoundException, SQLException {
		connCrime = DBUtil.createConnection();
		String query = "INSERT INTO Incidents(IncidentType, IncidentDate, Location, Description, Status, VictimID, SuspectID) "
				+ "VALUES( ?, ?, ?, ?, ?, ?, ?)";

		Date incDate = Date.valueOf(incident.getIncidentDate());

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		
		prepareStIncident.setString(1, incident.getIncidentType());
		prepareStIncident.setDate(2, incDate);
		prepareStIncident.setString(3, incident.getLocation());
		prepareStIncident.setString(4, incident.getDescription());
		prepareStIncident.setString(5, incident.getStatus());
		prepareStIncident.setInt(6, incident.getVictim().getVictimID());
		prepareStIncident.setInt(7, incident.getSuspect().getSuspectId());

		int result = prepareStIncident.executeUpdate();

		DBUtil.closeConnection();

		if (result > 0)
			return true;
		return false;
	}

	@Override
	public boolean updateIncidentStatus(String status, int incidentId)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {
		connCrime = DBUtil.createConnection();
		String query = "UPDATE Incidents SET Status=? " + "WHERE IncidentID=?";

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setString(1, status);
		prepareStIncident.setInt(2, incidentId);

		int result = prepareStIncident.executeUpdate();

		DBUtil.closeConnection();
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public int updateIncident(Incidents incident)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {
		connCrime = DBUtil.createConnection();
		String query = "UPDATE Incidents SET IncidentType=?, IncidentDate=?, Location=?, Description=?, Status=?, VictimID=?, SuspectID=? "
				+ "WHERE IncidentID=?";

		Date incDate = Date.valueOf(incident.getIncidentDate());

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setString(1, incident.getIncidentType());
		prepareStIncident.setDate(2, incDate);
		prepareStIncident.setString(3, incident.getLocation());
		prepareStIncident.setString(4, incident.getDescription());
		prepareStIncident.setString(5, incident.getStatus());
		prepareStIncident.setInt(6, incident.getVictim().getVictimID());
		prepareStIncident.setInt(7, incident.getSuspect().getSuspectId());
		prepareStIncident.setInt(8, incident.getIncidentID());

		int result = prepareStIncident.executeUpdate();

		DBUtil.closeConnection();
		return result;

	}

	@Override
	public int deleteIncident(int incidentID)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {

		Incidents incident = null;
		LocalDate incDate = null;

		connCrime = DBUtil.createConnection();

		String queryCheck = "SELECT * FROM Incidents WHERE IncidentID = ?";
		String queryDelete = "DELETE FROM Incidents WHERE IncidentID = ?";

		String incidentType = null;
		String location = null;
		String description = null;
		String status = null;

		int success = 0;

		PreparedStatement prepareStIncident = connCrime.prepareStatement(queryCheck);
		PreparedStatement prepareStDelete = connCrime.prepareStatement(queryDelete);

		prepareStIncident.setInt(1, incidentID);
		prepareStDelete.setInt(1, incidentID);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			incidentID = rsIncident.getInt("IncidentID");
			incidentType = rsIncident.getString("IncidentType");
			incDate = rsIncident.getDate("IncidentDate").toLocalDate();
			location = rsIncident.getString("Location");
			description = rsIncident.getString("Description");
			status = rsIncident.getString("Status");

			incident = new Incidents(incidentType, incDate, location, description, status);
		}

		if (incident == null) {
			throw new IncidentNumberNotFoundException("No Incident Found");
		} else {
			success = prepareStDelete.executeUpdate();
		}
		DBUtil.closeConnection();
		return success;
	}

	@Override
	public Incidents viewIncident(int incidentID)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {
		Incidents incident = null;

		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		Victims victim = null;

		int victimID = 0;
		String vFirstName = null;
		String vLastName = null;
		LocalDate vDateOfBirth = null;
		String vGender = null;
		String vContactInfo = null;

		Suspects suspect = null;

		int suspectID = 0;
		String sFirstName = null;
		String sLastName = null;
		LocalDate sDateOfBirth = null;
		String sGender = null;
		String sContactInfo = null;

		connCrime = DBUtil.createConnection();

		String queryCheck = "SELECT i.IncidentID,i.IncidentType,i.IncidentDate,i.Location,i.Description,i.Status, v.VictimID,v.FirstName,v.LastName,v.DateOfBirth,v.Gender,v.ContactInformation, s.SuspectID,s.FirstName,s.LastName,s.DateOfBirth,s.Gender,s.ContactInformation "
				+ " FROM Incidents i JOIN Victims v "
				+ "ON i.victimId = v.VictimID JOIN Suspects s ON i.SuspectID = s.SuspectID " + "WHERE IncidentID = ?";

		PreparedStatement prepareStIncident = connCrime.prepareStatement(queryCheck);
		prepareStIncident.setInt(1, incidentID);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			incidentID = rsIncident.getInt("i.IncidentID");
			incidentType = rsIncident.getString("i.IncidentType");
			incDate = rsIncident.getDate("i.IncidentDate").toLocalDate();
			location = rsIncident.getString("i.Location");
			description = rsIncident.getString("i.Description");
			status = rsIncident.getString("i.Status");

			victimID = rsIncident.getInt("v.VictimID");
			vFirstName = rsIncident.getString("v.FirstName");
			vLastName = rsIncident.getString("v.LastName");
			vDateOfBirth = rsIncident.getDate("v.DateOfBirth").toLocalDate();
			vGender = rsIncident.getString("v.Gender");
			vContactInfo = rsIncident.getString("v.ContactInformation");

			suspectID = rsIncident.getInt("s.SuspectID");
			sFirstName = rsIncident.getString("s.FirstName");
			sLastName = rsIncident.getString("s.LastName");
			sDateOfBirth = rsIncident.getDate("s.DateOfBirth").toLocalDate();
			sGender = rsIncident.getString("s.Gender");
			sContactInfo = rsIncident.getString("s.ContactInformation");

			victim = new Victims(victimID, vFirstName, vLastName, vDateOfBirth, vGender, vContactInfo);

			suspect = new Suspects(suspectID, sFirstName, sLastName, sDateOfBirth, sGender, sContactInfo);

			incident = new Incidents(incidentID, incidentType, incDate, location, description, status, victim, suspect);

		}
		DBUtil.closeConnection();

		if (incident == null) {
			throw new IncidentNumberNotFoundException("No Incident Found");
		}

		return incident;
	}

	@Override
	public List<Incidents> viewIncidents()
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {

		IVictimService victimService = new VictimServiceImpl();
		ISuspectService suspectService = new SuspectServiceImpl();
		List<Incidents> incidents = new ArrayList<>();
		Incidents incident = null;

		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		Victims victim = null;
		Suspects suspect = null;

		connCrime = DBUtil.createConnection();

		String query = "SELECT * FROM Incidents";

		int incidentID = 0;
		int victimID = 0;
		int suspectID = 0;

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			victimID = rsIncident.getInt("VictimID");
			suspectID = rsIncident.getInt("SuspectID");
			incidentID = rsIncident.getInt("IncidentID");
			incidentType = rsIncident.getString("IncidentType");
			incDate = rsIncident.getDate("IncidentDate").toLocalDate();
			location = rsIncident.getString("Location");
			description = rsIncident.getString("Description");
			status = rsIncident.getString("Status");
			victim = victimService.viewVictim(victimID);
			suspect = suspectService.viewSuspect(suspectID);

			incident = new Incidents(incidentID, incidentType, incDate, location, description, status, victim, suspect);
			incidents.add(incident);
		}
		DBUtil.closeConnection();

		if (incidents.size() == 0) {
			throw new IncidentNumberNotFoundException("No Incidents Found");
		}

		return incidents;
	}

	@Override
	public List<Incidents> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {
		IVictimService victimService = new VictimServiceImpl();
		ISuspectService suspectService = new SuspectServiceImpl();
		List<Incidents> incidents = new ArrayList<>();
		Incidents incident = null;

		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		Date sDate = Date.valueOf(startDate);
		Date eDate = Date.valueOf(endDate);

		Victims victim = null;
		Suspects suspect = null;

		connCrime = DBUtil.createConnection();

		String query = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?";

		int incidentID = 0;
		int victimID = 0;
		int suspectID = 0;

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setDate(1, sDate);
		prepareStIncident.setDate(2, eDate);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			victimID = rsIncident.getInt("VictimID");
			suspectID = rsIncident.getInt("SuspectID");
			incidentID = rsIncident.getInt("IncidentID");
			incidentType = rsIncident.getString("IncidentType");
			incDate = rsIncident.getDate("IncidentDate").toLocalDate();
			location = rsIncident.getString("Location");
			description = rsIncident.getString("Description");
			status = rsIncident.getString("Status");
			victim = victimService.viewVictim(victimID);
			suspect = suspectService.viewSuspect(suspectID);

			incident = new Incidents(incidentID, incidentType, incDate, location, description, status, victim, suspect);
			incidents.add(incident);
		}
		DBUtil.closeConnection();

		if (incidents.size() == 0) {
			throw new IncidentNumberNotFoundException("No Incident Found");
		}

		return incidents;

	}

	@Override
	public List<Incidents> searchIncidents(String incidentType)
			throws ClassNotFoundException, SQLException, IncidentNumberNotFoundException {
		IVictimService victimService = new VictimServiceImpl();
		ISuspectService suspectService = new SuspectServiceImpl();
		List<Incidents> incidents = new ArrayList<>();
		Incidents incident = null;

		String incType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		Victims victim = null;
		Suspects suspect = null;

		connCrime = DBUtil.createConnection();

		String query = "SELECT * FROM Incidents WHERE IncidentType = ?";

		int incidentID = 0;
		int victimID = 0;
		int suspectID = 0;

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setString(1, incidentType);

		ResultSet rsIncident = prepareStIncident.executeQuery();

		while (rsIncident.next()) {// Till there are further records.
			victimID = rsIncident.getInt("VictimID");
			suspectID = rsIncident.getInt("SuspectID");
			incidentID = rsIncident.getInt("IncidentID");
			incType = rsIncident.getString("IncidentType");
			incDate = rsIncident.getDate("IncidentDate").toLocalDate();
			location = rsIncident.getString("Location");
			description = rsIncident.getString("Description");
			status = rsIncident.getString("Status");
			victim = victimService.viewVictim(victimID);
			suspect = suspectService.viewSuspect(suspectID);

			incident = new Incidents(incidentID, incType, incDate, location, description, status, victim, suspect);
			incidents.add(incident);
		}
		DBUtil.closeConnection();

		if (incidents.size() == 0) {
			throw new IncidentNumberNotFoundException("No Incident Found");
		}

		return incidents;

	}

	@Override
	public Reports generateIncidentReport(Incidents incident)
			throws ClassNotFoundException, SQLException, ReportNotFoundException {

		Incidents incident1 = null;
		int incidentID = 0;
		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		int reportId = 0;
		Reports report = null;

		LocalDate rReportDate = null;
		String rReportDetails = null;
		String rStatus = null;

		Officers reportingOfficer = null;

		int officerID = 0;

		String oFirstName = null;
		String oLastName = null;
		String oBadgeNumber = null;
		String oRank = null;
		String oContactInfo = null;

		lawEnforcementAgencies lea = null;
		int agencyID = 0;
		String lAgencyName = null;
		String lJurisdiction = null;
		String lContactInfo = null;

		connCrime = DBUtil.createConnection();

		String queryCheck = "SELECT i.IncidentID,i.IncidentType,i.IncidentDate,i.Location,i.Description,i.Status,"
				+ " r.ReportID, r.IncidentID, r.ReportingOfficer, r.ReportDate, r.ReportDetails, r.Status,"
				+ " o.OfficerID,o.FirstName, o.LastName, o.BadgeNumber,o.RankP,o.ContactInformation"
				+ " l.AgencyID, l.AgencyName, l.Jurisdiction ,l.ContactInformation "
				+ " FROM Incidents i JOIN Reports r "
				+ " ON i.IncidentID = r.IncidentID JOIN Officers o ON r.ReportingOfficer = o.OfficerID "
				+ " JOIN lawenforcementagencies l ON o.OfficerID = l.OfficerID " + "WHERE i.IncidentID = ?";

		PreparedStatement prepareStReport = connCrime.prepareStatement(queryCheck);
		prepareStReport.setInt(1, incident.getIncidentID());

		ResultSet rsReport = prepareStReport.executeQuery();

		while (rsReport.next()) {// Till there are further records.
			incidentID = rsReport.getInt("i.IncidentID");
			incidentType = rsReport.getString("i.IncidentType");
			incDate = rsReport.getDate("i.IncidentDate").toLocalDate();
			location = rsReport.getString("i.Location");
			description = rsReport.getString("i.Description");
			status = rsReport.getString("i.Status");

			agencyID = rsReport.getInt("l.AgencyID");
			lAgencyName = rsReport.getString("l.AgencyName");
			lJurisdiction = rsReport.getString("l.Jurisdiction");
			lContactInfo = rsReport.getString("l.ContactInformation");

			reportId = rsReport.getInt("r.ReportID");
			rReportDate = rsReport.getDate("r.ReportDate").toLocalDate();
			rReportDetails = rsReport.getString("r.ReportDetails");
			rStatus = rsReport.getString("r.Status");

			officerID = rsReport.getInt("o.OfficerID");
			oFirstName = rsReport.getString("o.FirstName");
			oLastName = rsReport.getString("o.LastName");
			oBadgeNumber = rsReport.getString("o.BadgeNumber");
			oRank = rsReport.getString("o.RankP");
			oContactInfo = rsReport.getString("o.ContactInformation");

			lea = new lawEnforcementAgencies(agencyID, lAgencyName, lJurisdiction, lContactInfo);
			reportingOfficer = new Officers(officerID, oFirstName, oLastName, oBadgeNumber, oRank, oContactInfo, lea);
			incident1 = new Incidents(incidentID, incidentType, incDate, location, description, status);
			report = new Reports(reportId, incident1, reportingOfficer, rReportDate, rReportDetails, rStatus);
		}
		DBUtil.closeConnection();

		if (report == null) {
			throw new ReportNotFoundException("No report Found");
		}

		return report;

	}

	@Override
	public Boolean createCase(String caseDescription, Incidents incident) throws ClassNotFoundException, SQLException {
		connCrime = DBUtil.createConnection();
		String query = "INSERT INTO Case1(CaseDescription, IncidentID) " + "VALUES(?, ?)";

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setString(1, caseDescription);
		prepareStIncident.setInt(2, incident.getIncidentID());

		int result = prepareStIncident.executeUpdate();

		DBUtil.closeConnection();

		if (result > 0)
			return true;
		return false;

	}

	@Override
	public Case getCaseDetails(int caseId) throws ClassNotFoundException, SQLException, CaseNotFoundException {

		Case case1 = null;

		int caseID = 0;
		String caseDesc = null;

		Incidents incident = null;

		int incidentId = 0;
		String incidentType = null;
		LocalDate incDate = null;
		String location = null;
		String description = null;
		String status = null;

		Victims victim = null;

		int victimID = 0;
		String vFirstName = null;
		String vLastName = null;
		LocalDate vDateOfBirth = null;
		String vGender = null;
		String vContactInfo = null;

		Suspects suspect = null;

		int suspectID = 0;
		String sFirstName = null;
		String sLastName = null;
		LocalDate sDateOfBirth = null;
		String sGender = null;
		String sContactInfo = null;

		connCrime = DBUtil.createConnection();

		String query = "SELECT c.CaseId,c.CaseDescription,i.IncidentID,i.IncidentType,i.IncidentDate,i.Location,i.Description,i.Status, v.VictimID,v.FirstName,v.LastName,v.DateOfBirth,v.Gender,v.ContactInformation, s.SuspectID,s.FirstName,s.LastName,s.DateOfBirth,s.Gender,s.ContactInformation "
				+ " FROM Case1 c JOIN Incidents i ON c.IncidentId = i.IncidentID JOIN Victims v "
				+ "ON i.victimId = v.VictimID JOIN Suspects s ON i.SuspectID = s.SuspectID " + "WHERE CaseId = ?";

		PreparedStatement prepareStCase = connCrime.prepareStatement(query);

		prepareStCase.setInt(1, caseId);

		ResultSet rsCase = prepareStCase.executeQuery();

		while (rsCase.next()) {// Till there are further records.

			caseID = rsCase.getInt("c.CaseId");
			caseDesc = rsCase.getString("c.CaseDescription");

			incidentId = rsCase.getInt("i.IncidentID");
			incidentType = rsCase.getString("i.IncidentType");
			incDate = rsCase.getDate("i.IncidentDate").toLocalDate();
			location = rsCase.getString("i.Location");
			description = rsCase.getString("i.Description");
			status = rsCase.getString("i.Status");

			victimID = rsCase.getInt("v.VictimID");
			vFirstName = rsCase.getString("v.FirstName");
			vLastName = rsCase.getString("v.LastName");
			vDateOfBirth = rsCase.getDate("v.DateOfBirth").toLocalDate();
			vGender = rsCase.getString("v.Gender");
			vContactInfo = rsCase.getString("v.ContactInformation");

			suspectID = rsCase.getInt("s.SuspectID");
			sFirstName = rsCase.getString("s.FirstName");
			sLastName = rsCase.getString("s.LastName");
			sDateOfBirth = rsCase.getDate("s.DateOfBirth").toLocalDate();
			sGender = rsCase.getString("s.Gender");
			sContactInfo = rsCase.getString("s.ContactInformation");

			victim = new Victims(victimID, vFirstName, vLastName, vDateOfBirth, vGender, vContactInfo);

			suspect = new Suspects(suspectID, sFirstName, sLastName, sDateOfBirth, sGender, sContactInfo);

			incident = new Incidents(incidentId, incidentType, incDate, location, description, status, victim, suspect);

			case1 = new Case(caseID, caseDesc, incident);

		}
		DBUtil.closeConnection();

		if (incident == null) {
			throw new CaseNotFoundException("No Case Found");
		}

		return case1;

	}

	@Override
	public boolean updateCaseDetails(Case case1) throws ClassNotFoundException, SQLException, CaseNotFoundException {
		connCrime = DBUtil.createConnection();
		String query = "UPDATE Case1 SET CaseDescription=?, IncidentId=? WHERE CaseId=?";

		PreparedStatement prepareStIncident = connCrime.prepareStatement(query);
		prepareStIncident.setString(1, case1.getCaseDescription());
		prepareStIncident.setInt(2, case1.getIncident().getIncidentID());
		prepareStIncident.setInt(3, case1.getCaseId());
		int result = prepareStIncident.executeUpdate();

		DBUtil.closeConnection();
		if (result > 0)
			return true;
		return false;

	}

	@Override
	public List<Case> getAllCases() throws ClassNotFoundException, SQLException, CaseNotFoundException {
		ICrimeAnalysisService incidentService = new CrimeAnalysisServiceImpl();

		List<Case> Cases = new ArrayList<>();

		Case case1 = null;

		int caseID = 0;
		String caseDesc = null;

		Incidents incident = null;
		connCrime = DBUtil.createConnection();

		String query = "SELECT * FROM Case1";

		int incidentID = 0;
		PreparedStatement prepareStCase = connCrime.prepareStatement(query);

		ResultSet rsCase = prepareStCase.executeQuery();

		while (rsCase.next()) {// Till there are further records.
			incidentID = rsCase.getInt("IncidentId");
			caseDesc = rsCase.getString("CaseDescription");
			caseID = rsCase.getInt("CaseId");
			
			incident = incidentService.viewIncident(incidentID);

			case1 = new Case(caseID,caseDesc,incident);
			Cases.add(case1);
		}
		DBUtil.closeConnection();

		if (Cases.size() == 0) {
			throw new CaseNotFoundException("No Incidents Found");
		}

		return Cases;		

	}

}
