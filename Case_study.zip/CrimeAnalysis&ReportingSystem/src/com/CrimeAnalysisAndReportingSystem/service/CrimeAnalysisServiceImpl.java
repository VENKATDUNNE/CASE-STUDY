package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.CrimeAnalysisDAOImpl;
import com.CrimeAnalysisAndReportingSystem.dao.ICrimeAnalysisDAO;
import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.exception.CaseNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.IncidentNumberNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;

public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {
	
	private ICrimeAnalysisDAO icrimeAnalysisDAO;
	
	public CrimeAnalysisServiceImpl() {
		super();
		 icrimeAnalysisDAO = new CrimeAnalysisDAOImpl();
	}

	@Override
	public boolean createIncident(Incidents incident) {
		Boolean result = false;
		try {
			result = icrimeAnalysisDAO.createIncident(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public boolean updateIncidentStatus(String status, int incidentId) {
		Boolean result = false;
		try {
			result = icrimeAnalysisDAO.updateIncidentStatus(status,incidentId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			
		} catch(IncidentNumberNotFoundException ie){
			System.out.println(ie.getMessage());
			
		}
		return result;
	}

	@Override
	public List<Incidents> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate) {
		List<Incidents> incidentList = null;
		try {
			incidentList = icrimeAnalysisDAO.getIncidentsInDateRange(startDate, endDate);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch(IncidentNumberNotFoundException ie){
			System.out.println(ie.getMessage());
			
		}
		return incidentList;
	}

	@Override
	public List<Incidents> searchIncidents(String incidentType) {
		List<Incidents> incidentList = null;
		try {
			incidentList = icrimeAnalysisDAO.searchIncidents(incidentType);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch(IncidentNumberNotFoundException ie){
			System.out.println(ie.getMessage());
		}
		return incidentList;
	}

	@Override
	public Reports generateIncidentReport(Incidents incident) {
		Reports report = null;

		try {
			report = icrimeAnalysisDAO.generateIncidentReport(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (ReportNotFoundException re) {
			System.out.println(re.getMessage());
		}
		return report;

	}

	@Override
	public Boolean createCase(String caseDescription, Incidents incident) {
		Boolean result = false;
		try {
			result = icrimeAnalysisDAO.createCase(caseDescription, incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		return result;
	}

	@Override
	public Case getCaseDetails(int caseId) {
		Case case1 = null;

		try {
			case1 = icrimeAnalysisDAO.getCaseDetails(caseId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CaseNotFoundException ce) {
			System.out.println(ce.getMessage());
		}
		return case1;
	}

	@Override
	public boolean updateCaseDetails(Case case1) {
		Boolean result = false;
		try {
			result = icrimeAnalysisDAO.updateCaseDetails(case1);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch(CaseNotFoundException ce){
			System.out.println(ce.getMessage());			
		}
		return result;
	}

	@Override
	public List<Case> getAllCases() {
		List<Case> Cases = null;
		try {
			Cases = icrimeAnalysisDAO.getAllCases();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch(CaseNotFoundException ce){
			System.out.println(ce.getMessage());
			
		}
		return Cases;
		
	}

	@Override
	public int updateIncident(Incidents incident) {
		int result = 0;
		try {
			result = icrimeAnalysisDAO.updateIncident(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch(IncidentNumberNotFoundException ie){
			System.out.println(ie.getMessage());
			
		}
		return result;
		
	}

	@Override
	public int deleteIncident(int incidentID) {
		int result = 0;
		try {
			result = icrimeAnalysisDAO.deleteIncident(incidentID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(IncidentNumberNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public Incidents viewIncident(int incidentID) {
		Incidents incident = null;

		try {
			incident = icrimeAnalysisDAO.viewIncident(incidentID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (IncidentNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return incident;
	}

	@Override
	public List<Incidents> viewIncidents() {

		List<Incidents> incidentList = null;

		try {
			incidentList = icrimeAnalysisDAO.viewIncidents();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (IncidentNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return incidentList;

	}

}
