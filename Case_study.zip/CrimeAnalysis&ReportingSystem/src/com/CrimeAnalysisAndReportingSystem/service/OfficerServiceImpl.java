package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.IOfficerDAO;
import com.CrimeAnalysisAndReportingSystem.dao.OfficerDAOImpl;
import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.exception.OfficerNotFoundException;


public class OfficerServiceImpl implements IOfficerService {


	private IOfficerDAO officerDAO;

	public OfficerServiceImpl() {
		officerDAO = new OfficerDAOImpl();
	}
	
	@Override
	public int addOfficer(Officers officer) {
		int result = 0;
		try {
			result = officerDAO.addOfficer(officer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateOfficer(Officers officer) {
		int result = 0;
		try {
			result = officerDAO.updateOfficer(officer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return result;
	}

	@Override
	public int deleteOfficer(int officerID) {
		int result = 0;
		try {
			result = officerDAO.deleteOfficer(officerID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(OfficerNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		return result;
	}

	@Override
	public Officers viewOfficer(int officerID) {
		Officers officer = null;

		try {
			officer = officerDAO.viewOfficer(officerID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		return officer;
	}

	@Override
	public List<Officers> viewOfficers() {
		List<Officers> officerList = null;

		try {
			officerList = officerDAO.viewOfficers();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		return officerList;
	}

}
