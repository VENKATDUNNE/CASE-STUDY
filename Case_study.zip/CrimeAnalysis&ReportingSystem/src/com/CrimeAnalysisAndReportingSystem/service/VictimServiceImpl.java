package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.IVictimDAO;
import com.CrimeAnalysisAndReportingSystem.dao.VictimDAOImpl;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.VictimNotFoundException;

public class VictimServiceImpl implements IVictimService {
	private IVictimDAO iVictimDAO;

	public VictimServiceImpl() {
		super();
		iVictimDAO = new VictimDAOImpl();
	}

	@Override
	public int addVictim(Victims victim) {
		int result = 0;
		try {
			result = iVictimDAO.addVictim(victim);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateVictim(Victims victim) {
		int result = 0;
		try {
			result = iVictimDAO.updateVictim(victim);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (VictimNotFoundException ve) {
			System.out.println(ve.getMessage());
		}
		return result;
	}

	@Override
	public int deleteVictim(int victimId) {
		int result = 0;
		try {
			result = iVictimDAO.deleteVictim(victimId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (VictimNotFoundException ve) {
			System.out.println(ve.getMessage());
		}

		return result;
	}

	@Override
	public Victims viewVictim(int victimId) {
		Victims victim = null;

		try {
			victim = iVictimDAO.viewVictim(victimId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (VictimNotFoundException ve) {
			System.out.println(ve.getMessage());
		}

		return victim;
	}

	@Override
	public List<Victims> viewVictims() {
		List<Victims> victimList = null;

		try {
			victimList = iVictimDAO.viewVictims();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (VictimNotFoundException ve) {
			System.out.println(ve.getMessage());
		}
		return victimList;
	}

}
