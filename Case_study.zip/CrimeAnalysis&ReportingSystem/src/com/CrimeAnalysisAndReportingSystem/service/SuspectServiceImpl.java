package com.CrimeAnalysisAndReportingSystem.service;

import java.sql.SQLException;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.dao.ISuspectDAO;
import com.CrimeAnalysisAndReportingSystem.dao.SuspectDAOImpl;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.exception.SuspectNotFoundException;

public class SuspectServiceImpl implements ISuspectService {
	private ISuspectDAO iSuspectDAO;

	public SuspectServiceImpl() {
		super();
		iSuspectDAO = new SuspectDAOImpl();
	}

	@Override
	public int addSuspect(Suspects suspect) {
		int result = 0;
		try {
			result = iSuspectDAO.addSuspect(suspect);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		return result;
	}

	@Override
	public int updateSuspect(Suspects suspect) {
		int result = 0;
		try {
			result = iSuspectDAO.updateSuspect(suspect);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (SuspectNotFoundException ve) {
			System.out.println(ve.getMessage());
		}
		return result;
	}

	@Override
	public int deleteSuspect(int suspectId) {
		int result = 0;
		try {
			result = iSuspectDAO.deleteSuspect(suspectId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (SuspectNotFoundException ve) {
			System.out.println(ve.getMessage());
		}

		return result;
	}

	@Override
	public Suspects viewSuspect(int suspectId) {
		Suspects suspect = null;

		try {
			suspect = iSuspectDAO.viewSuspect(suspectId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (SuspectNotFoundException ve) {
			System.out.println(ve.getMessage());
		}

		return suspect;
	}

	@Override
	public List<Suspects> viewSuspects() {
		List<Suspects> suspectList = null;

		try {
			suspectList = iSuspectDAO.viewSuspects();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (SuspectNotFoundException ve) {
			System.out.println(ve.getMessage());
		}
		return suspectList;
	}
}
