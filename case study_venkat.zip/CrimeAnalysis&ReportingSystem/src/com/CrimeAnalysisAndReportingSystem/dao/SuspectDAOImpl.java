package com.CrimeAnalysisAndReportingSystem.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.exception.SuspectNotFoundException;
import com.CrimeAnalysisAndReportingSystem.util.DBUtil;

public class SuspectDAOImpl implements ISuspectDAO {


	private static Connection connSuspect;

	@Override
	public int addSuspect(Suspects suspect) throws ClassNotFoundException, SQLException {
		connSuspect = DBUtil.createConnection();
		String query = "INSERT INTO Suspects(FirstName,LastName,DateOfBirth,Gender,ContactInformation) VALUES(?,?,?,?,?)";
		int result = 0;
		Date Dob = Date.valueOf(suspect.getDateOfBirth());

		PreparedStatement prepareStSuspect = connSuspect.prepareStatement(query);
		prepareStSuspect.setString(1, suspect.getFirstName());
		prepareStSuspect.setString(2, suspect.getLastName());
		prepareStSuspect.setDate(3, Dob);
		prepareStSuspect.setString(4, suspect.getGender());
		prepareStSuspect.setString(5, suspect.getPhoneNumber());

		result = prepareStSuspect.executeUpdate();

		DBUtil.closeConnection();

		return result;

	}

	@Override
	public int updateSuspect(Suspects suspect) throws ClassNotFoundException, SQLException, SuspectNotFoundException {
		connSuspect = DBUtil.createConnection();
		String query = "UPDATE Suspects SET FirstName=?,LastName=?,DateOfBirth=?,Gender=?,ContactInformation=? WHERE SuspectId=?";
		int result = 0;
		Date Dob = Date.valueOf(suspect.getDateOfBirth());

		PreparedStatement prepareStSuspect = connSuspect.prepareStatement(query);
		prepareStSuspect.setString(1, suspect.getFirstName());
		prepareStSuspect.setString(2, suspect.getLastName());
		prepareStSuspect.setDate(3, Dob);
		prepareStSuspect.setString(4, suspect.getGender());
		prepareStSuspect.setString(5, suspect.getPhoneNumber());
		prepareStSuspect.setInt(6, suspect.getSuspectId());

		result = prepareStSuspect.executeUpdate();
		DBUtil.closeConnection();
		return result;

	}

	@Override
	public int deleteSuspect(int suspectId) throws ClassNotFoundException, SQLException, SuspectNotFoundException {
		connSuspect = DBUtil.createConnection();
		Suspects suspect = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;
		int result = 0;

		String queryCheck = "SELECT * FROM Suspects WHERE SuspectId = ?";
		String queryDelete = "DELETE FROM Suspects WHERE SuspectId = ?";

		PreparedStatement prepareStSuspect = connSuspect.prepareStatement(queryCheck);
		PreparedStatement prepareSuspectDelete = connSuspect.prepareStatement(queryDelete);

		prepareStSuspect.setInt(1, suspectId);
		prepareSuspectDelete.setInt(1, suspectId);

		ResultSet rsSuspects = prepareStSuspect.executeQuery();

		while (rsSuspects.next()) {// Till there are further records.
			suspectId = rsSuspects.getInt("SuspectId");
			firstName = rsSuspects.getString("firstname");
			lastName = rsSuspects.getString("lastname");
			Dob = rsSuspects.getDate("DateOfBirth").toLocalDate();
			gender = rsSuspects.getString("Gender");
			phoneNumber = rsSuspects.getString("ContactInformation");

			suspect = new Suspects(firstName, lastName, Dob, gender, phoneNumber);
			suspect.setSuspectId(suspectId);
		}

		if (suspect == null) {
			throw new SuspectNotFoundException("No Suspects Found");
		} else {
			result = prepareSuspectDelete.executeUpdate();
		}

		DBUtil.closeConnection();
		return result;
	}

	@Override
	public Suspects viewSuspect(int suspectId) throws ClassNotFoundException, SQLException, SuspectNotFoundException {
		connSuspect = DBUtil.createConnection();
		Suspects suspect = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;

		String query = "SELECT * FROM Suspects WHERE SuspectId = ?";

		PreparedStatement prepareStSuspects = connSuspect.prepareStatement(query);

		prepareStSuspects.setInt(1, suspectId);

		ResultSet rsSuspects = prepareStSuspects.executeQuery();

		while (rsSuspects.next()) {// Till there are further records.
			suspectId = rsSuspects.getInt("SuspectId");
			firstName = rsSuspects.getString("firstname");
			lastName = rsSuspects.getString("lastname");
			Dob = rsSuspects.getDate("DateOfBirth").toLocalDate();
			gender = rsSuspects.getString("Gender");
			phoneNumber = rsSuspects.getString("ContactInformation");

			suspect = new Suspects(firstName, lastName, Dob, gender, phoneNumber);
			suspect.setSuspectId(suspectId);
		}

		DBUtil.closeConnection();

		if (suspect == null) {
			throw new SuspectNotFoundException("No Suspects Found");
		}

		return suspect;
	}

	@Override
	public List<Suspects> viewSuspects() throws ClassNotFoundException, SQLException, SuspectNotFoundException {
		List<Suspects> suspects = new ArrayList<>();
		connSuspect = DBUtil.createConnection();
		Suspects suspect = null;
		String firstName = null;
		String lastName = null;
		LocalDate Dob = null;
		String gender = null;
		String phoneNumber = null;
		int SuspectId = 0;

		String query = "SELECT * FROM Suspects";

		PreparedStatement prepareStSuspects = connSuspect.prepareStatement(query);

		ResultSet rsSuspects = prepareStSuspects.executeQuery();

		while (rsSuspects.next()) {// Till there are further records.
			SuspectId = rsSuspects.getInt("SuspectId");
			firstName = rsSuspects.getString("firstname");
			lastName = rsSuspects.getString("lastname");
			Dob = rsSuspects.getDate("DateOfBirth").toLocalDate();
			gender = rsSuspects.getString("Gender");
			phoneNumber = rsSuspects.getString("ContactInformation");

			suspect = new Suspects(firstName, lastName, Dob, gender, phoneNumber);
			suspect.setSuspectId(SuspectId);
			suspects.add(suspect);
		}

		DBUtil.closeConnection();

		if (suspects.size() == 0) {
			throw new SuspectNotFoundException("No Suspects Found");
		}

		return suspects;
	}

}
