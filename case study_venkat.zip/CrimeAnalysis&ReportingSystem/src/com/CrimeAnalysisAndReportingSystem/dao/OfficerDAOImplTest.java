package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Officers;
import com.CrimeAnalysisAndReportingSystem.entity.lawEnforcementAgencies;
import com.CrimeAnalysisAndReportingSystem.exception.OfficerNotFoundException;


public class OfficerDAOImplTest {
	private IOfficerDAO officerDAO;

	@Before
	public void setUp() throws Exception {
		officerDAO = new OfficerDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		officerDAO = null;
	}

	@Test
	public final void testAddOfficer() {
		int result = 0;
		lawEnforcementAgencies lea = new lawEnforcementAgencies();
		int agencyID = 5;
		lea.setAgencyId(agencyID);
		Officers officer = new Officers(5, "Raja", "Kumar", "1016", "Sub-Inspector", "9708968790", lea);
		try {
			result = officerDAO.addOfficer(officer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testUpdateOfficer() {
		int result = 0;
		lawEnforcementAgencies lea = new lawEnforcementAgencies();
		int agencyID = 2;
		lea.setAgencyId(agencyID);
		Officers officer = new Officers(4, "Ravi", "Teja", "1012", "Sub-Inspector", "97088907999", lea);
		try {
			result = officerDAO.updateOfficer(officer);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		}catch(SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}catch(OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(result == 1);
	}

	@Test
	public final void testDeleteOfficer() {
		int result = 0;
		int officerID = 3;
		try {
			result = officerDAO.deleteOfficer(officerID);
			}catch (ClassNotFoundException cnfe) {
				System.out.println("Looks like JDBC driver is NOT loaded.");
			}catch(SQLException se) {
				System.out.println("Either url, username or password is wrong or duplicate record");
				se.printStackTrace();
			}catch(OfficerNotFoundException cnfe) {
				System.out.println(cnfe.getMessage());
			}
		
		assertTrue(result == 1);
	}

	@Test
	public final void testViewOfficer() {
		Officers officer = null;
		int officerID = 1;

		try {
			officer = officerDAO.viewOfficer(officerID);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(officer != null);
	}

	@Test
	public final void testViewOfficers() {
		List<Officers> officerList = null;

		try {
			officerList = officerDAO.viewOfficers();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (OfficerNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(officerList != null);
	}

}
