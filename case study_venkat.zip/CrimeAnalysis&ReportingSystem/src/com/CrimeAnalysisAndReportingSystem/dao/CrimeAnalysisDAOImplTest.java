package com.CrimeAnalysisAndReportingSystem.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.CrimeAnalysisAndReportingSystem.entity.Case;
import com.CrimeAnalysisAndReportingSystem.entity.Incidents;
import com.CrimeAnalysisAndReportingSystem.entity.Reports;
import com.CrimeAnalysisAndReportingSystem.entity.Suspects;
import com.CrimeAnalysisAndReportingSystem.entity.Victims;
import com.CrimeAnalysisAndReportingSystem.exception.CaseNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.IncidentNumberNotFoundException;
import com.CrimeAnalysisAndReportingSystem.exception.ReportNotFoundException;

public class CrimeAnalysisDAOImplTest {
	private ICrimeAnalysisDAO icrimeAnalysisDAO;

	@Before
	public void setUp() throws Exception {
		icrimeAnalysisDAO = new CrimeAnalysisDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		icrimeAnalysisDAO = null;
	}

	@Test
	public final void testCreateIncident() {
		Boolean result = false;
		Victims victim = new Victims();
		int VictimID = 10;
		victim.setVictimID(VictimID);
		Suspects suspect = new Suspects();
		int SuspectID = 10;
		suspect.setSuspectId(SuspectID);
		LocalDate date = LocalDate.of(2023, 11, 27);
		Incidents incident = new Incidents("Robbery", date, "123.7,88", "girl died at shop", "Open", victim, suspect);
		try {
			result = icrimeAnalysisDAO.createIncident(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		}
		assertTrue(result == true);

	}

	@Test
	public final void testUpdateIncidentStatus() {
		Boolean result = false;
		String status = "Closed";
		int id = 10;
		try {
			result = icrimeAnalysisDAO.updateIncidentStatus(status, id);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (IncidentNumberNotFoundException ie) {
			System.out.println(ie.getMessage());

		}
		assertTrue(result == true);
	}

	@Test
	public final void testUpdateIncident() {
		int result = 0;
		Victims victim = new Victims();
		int VictimID = 10;
		victim.setVictimID(VictimID);
		Suspects suspect = new Suspects();
		int SuspectID = 10;
		suspect.setSuspectId(SuspectID);
		LocalDate date = LocalDate.of(2023, 11, 27);
		Incidents incident = new Incidents(5, "Robbery", date, "123.7,88", "girl died at shop", "Open", victim,
				suspect);
		try {
			result = icrimeAnalysisDAO.updateIncident(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (IncidentNumberNotFoundException ie) {
			System.out.println(ie.getMessage());

		}
		assertTrue(result != 0);
	}

	@Test
	public final void testDeleteIncident() {
		int result = 0;
		int incidentId = 4;
		try {
			result = icrimeAnalysisDAO.deleteIncident(incidentId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (IncidentNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(result != 0);
	}

	@Test
	public final void testViewIncident() {
		Incidents incident = null;
		int incidentId = 4;
		try {
			incident = icrimeAnalysisDAO.viewIncident(incidentId);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (IncidentNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}

		assertTrue(incident != null);

	}

	@Test
	public final void testViewIncidents() {
		List<Incidents> incidentList = null;

		try {
			incidentList = icrimeAnalysisDAO.viewIncidents();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		} catch (IncidentNumberNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		assertTrue(incidentList != null);
	}

	@Test
	public final void testGetIncidentsInDateRange() {
		List<Incidents> incidentList = null;
		LocalDate sdate = LocalDate.of(2023, 11, 27);
		LocalDate edate = LocalDate.of(2023, 12, 27);

		try {
			incidentList = icrimeAnalysisDAO.getIncidentsInDateRange(sdate, edate);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (IncidentNumberNotFoundException ie) {
			System.out.println(ie.getMessage());

		}
		assertTrue(incidentList != null);
	}

	@Test
	public final void testSearchIncidents() {
		List<Incidents> incidentList = null;
		String it = "Robbery";
		try {
			incidentList = icrimeAnalysisDAO.searchIncidents(it);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (IncidentNumberNotFoundException ie) {
			System.out.println(ie.getMessage());
		}
		assertTrue(incidentList != null);
	}

	@Test
	public final void testGenerateIncidentReport() {
		Reports report = null;

		Victims victim = new Victims();
		int VictimID = 5;
		victim.setVictimID(VictimID);
		Suspects suspect = new Suspects();
		int SuspectID = 5;
		suspect.setSuspectId(SuspectID);
		LocalDate date = LocalDate.of(2023, 05, 20);
		Incidents incident = new Incidents(5, "Theft", date, "32.7157, 117.1611", "Break-in at a residential property",
				"Closed", victim, suspect);

		try {
			report = icrimeAnalysisDAO.generateIncidentReport(incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (ReportNotFoundException re) {
			System.out.println(re.getMessage());
		}
		assertTrue(report != null);
	}

	@Test
	public final void testCreateCase() {
		Boolean result = false;
		String desc = "murder";
		Victims victim = new Victims();
		int VictimID = 10;
		victim.setVictimID(VictimID);
		Suspects suspect = new Suspects();
		int SuspectID = 10;
		suspect.setSuspectId(SuspectID);
		LocalDate date = LocalDate.of(2023, 11, 27);
		Incidents incident = new Incidents(6, "Robbery", date, "123.7,88", "girl died at shop", "Open", victim,
				suspect);

		try {
			result = icrimeAnalysisDAO.createCase(desc, incident);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
			se.printStackTrace();
		}
		assertTrue(result == true);
	}

	@Test
	public final void testGetCaseDetails() {
		Case case1 = null;
		int cid = 1;
		try {
			case1 = icrimeAnalysisDAO.getCaseDetails(cid);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CaseNotFoundException ce) {
			System.out.println(ce.getMessage());
		}
		assertTrue(case1 != null);
	}

	@Test
	public final void testUpdateCaseDetails() {
		Boolean result = false;
		Incidents incident = new Incidents();
		int ID = 10;
		incident.setIncidentID(ID);
		
		Case case1= new Case(5, "murder bad", incident);
		try {
			result = icrimeAnalysisDAO.updateCaseDetails(case1);
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CaseNotFoundException ce) {
			System.out.println(ce.getMessage());
		}
		assertTrue(result == true);
	}

	@Test
	public final void testGetAllCases() {
		List<Case> Cases = null;
		try {
			Cases = icrimeAnalysisDAO.getAllCases();
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Looks like JDBC driver is NOT loaded.");
		} catch (SQLException se) {
			System.out.println("Either url, username or password is wrong or duplicate record");
		} catch (CaseNotFoundException ce) {
			System.out.println(ce.getMessage());

		}
		assertTrue(Cases != null);
	}

}
