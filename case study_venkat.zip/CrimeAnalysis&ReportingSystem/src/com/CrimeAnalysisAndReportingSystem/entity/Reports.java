package com.CrimeAnalysisAndReportingSystem.entity;

import java.time.LocalDate;
import java.util.Objects;

public class Reports {
	 private int  reportId;
	 private Incidents  incident;
     private Officers reportingOfficer;
     private LocalDate reportDate;
     private String reportDetails;
     private String status;
     
     
	public Reports(LocalDate reportDate, String reportDetails, String status) {
		super();
		this.reportDate = reportDate;
		this.reportDetails = reportDetails;
		this.status = status;
	}
	public Reports() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reports(int reportId, Incidents incident, Officers reportingOfficer, LocalDate reportDate,
			String reportDetails, String status) {
		super();
		this.reportId = reportId;
		this.incident = incident;
		this.reportingOfficer = reportingOfficer;
		this.reportDate = reportDate;
		this.reportDetails = reportDetails;
		this.status = status;
	}
	public Reports(Incidents incident, Officers reportingOfficer, LocalDate reportDate, String reportDetails,
			String status) {
		super();
		this.incident = incident;
		this.reportingOfficer = reportingOfficer;
		this.reportDate = reportDate;
		this.reportDetails = reportDetails;
		this.status = status;
	}
	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public Incidents getIncident() {
		return incident;
	}
	public void setIncident(Incidents incident) {
		this.incident = incident;
	}
	public Officers getReportingOfficer() {
		return reportingOfficer;
	}
	public void setReportingOfficer(Officers reportingOfficer) {
		this.reportingOfficer = reportingOfficer;
	}
	public LocalDate getReportDate() {
		return reportDate;
	}
	public void setReportDate(LocalDate reportDate) {
		this.reportDate = reportDate;
	}
	public String getReportDetails() {
		return reportDetails;
	}
	public void setReportDetails(String reportDetails) {
		this.reportDetails = reportDetails;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public int hashCode() {
		return Objects.hash(incident, reportDate, reportDetails, reportId, reportingOfficer, status);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reports other = (Reports) obj;
		return Objects.equals(incident, other.incident) && Objects.equals(reportDate, other.reportDate)
				&& Objects.equals(reportDetails, other.reportDetails) && reportId == other.reportId
				&& Objects.equals(reportingOfficer, other.reportingOfficer) && Objects.equals(status, other.status);
	}
	@Override
	public String toString() {
		return "Reports [reportId=" + reportId + ", incident=" + incident + ", reportingOfficer=" + reportingOfficer
				+ ", reportDate=" + reportDate + ", reportDetails=" + reportDetails + ", status=" + status + "]";
	}
     
}